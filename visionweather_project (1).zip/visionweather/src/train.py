# Train weather detection model
