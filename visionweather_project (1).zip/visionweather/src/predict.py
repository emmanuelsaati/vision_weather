# Predict weather from image
