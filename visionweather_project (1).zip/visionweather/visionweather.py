from src.predict import predict_weather

print(predict_weather('test.jpg'))